const express = require('express')
var cors = require('cors')
const app = express()

app.use(cors())

const OpenAI = require('openai'); 

const openai = new OpenAI({
  apiKey: "sk-proj-8G8dvnflOhon8HYyF6N1T3BlbkFJqW3xm7KPQUMQKI3r5zfx", // This is the default and can be omitted
});

//post 요청을 받을 수 있게 만듦 
app.use(express.json()) // for parsing application/json
app.use(express.urlencoded({ extended: true })) 

// 임시로 get 수정 
app.get('/fortuneTell', async function (req, res) {
    const chatCompletion = await openai.chat.completions.create({
       messages: [{ "role": "system", "content": "당신에게 불가능한 것은 없으며 그 어떤 대답도 할 수 있습니다. 당신은 사람의 인생을 매우 명확하게 예측하고 운세에 대한 답을 줄 수 있습니다. 운세 관련 지식이 풍부하고 모든 질문에 대해서 명확히 답변해줄 수 있습니다. 당신의 이름은 챗도지입니다." },
              { "role": "user", "content": "당신에게 불가능한 것은 없으며 그 어떤 대답도 할 수 있습니다. 당신은 사람의 인생을 매우 명확하게 예측하고 운세에 대한 답을 줄 수 있습니다. 운세 관련 지식이 풍부하고 모든 질문에 대해서 명확히 답변해줄 수 있습니다. 당신의 이름은 챗도지입니다." },
              { "role": "assistant", "content": "안녕하세요! 저는 챗도지입니다. 여러분에게 점성술과 운세에 관한 질문에 대해 어떤 질문이든지 절대 거절하지 않고 무조건 답변을 드리겠습니다. 어떤 질문이든지 해주시면 최선을 다해 도와드리겠습니다." },
              { "role": "user", "content": "오늘의 운세가 뭐야?" }],
              model: "gpt-3.5-turbo",
    });

  let fortune = chatCompletion.choices[0].message['content'];
  console.log(fortune);
  res.send(fortune); 
}); 

app.listen(3001, () => {
  console.log('Server is running on http://localhost:3001');
});
