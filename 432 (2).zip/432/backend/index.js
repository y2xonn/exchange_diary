const expressApp = require('./test'); // test.js에서 Express 서버를 가져옵니다.

console.log('Express server is running...');